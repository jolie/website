package example;

import jolie.runtime.JavaService;
import jolie.runtime.Value;

public class Splitter extends JavaService {

	public Value split( Value s_msg ){
		String string = s_msg.getFirstChild("string").strValue();
		String regExpr = s_msg.getFirstChild("regExpr").strValue();
		
		String[] sa = string.split( regExpr );

		Value s_res = Value.create();
		int i = 0;

		for( String s : sa ){
			s_res.getNewChild( "s_chunk" ).setValue( s );
		}

		return s_res;
	}
}