#!/bin/sh

./launch.sh leonardo/leonardo.ol UserWebUI/build/web/

