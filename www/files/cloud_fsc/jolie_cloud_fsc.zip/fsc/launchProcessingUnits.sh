#!/bin/bash

./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9001\"" processing_unit/processing_unit.ol &
./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9002\"" processing_unit/processing_unit.ol &
./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9003\"" processing_unit/processing_unit.ol &
./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9004\"" processing_unit/processing_unit.ol &
./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9005\"" processing_unit/processing_unit.ol &
./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9006\"" processing_unit/processing_unit.ol &
#./launch.sh -C "Location_ProcessingUnit=\"socket://localhost:9010\"" processing_unit/processing_unit.ol &
