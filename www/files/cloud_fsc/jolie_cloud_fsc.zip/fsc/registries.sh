#!/bin/sh

./launch.sh registry/registry.ol
