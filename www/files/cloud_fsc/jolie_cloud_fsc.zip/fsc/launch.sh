#!/bin/sh

FSC_HOME=.

jolie -i $FSC_HOME/common "$@"

