package fsc.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.VerticalPanel;
import fsc.client.ui.LoginWidget;
import fsc.client.ui.MainUI;
import joliex.gwt.client.JolieService;
import joliex.gwt.client.JolieServiceAsync;
import joliex.gwt.client.Value;

/**
 * Main entry point.
 *
 * @author Fabrizio Montesi
 */
public class UserWebUIEntryPoint implements EntryPoint
{
	private static final JolieServiceAsync service = JolieService.Util.getInstance();
	private final Panel mainPanel = new VerticalPanel();
	private final Value authenticationValue = new Value();
	
	public Value authenticationValue()
	{
		return authenticationValue;
	}

	public JolieServiceAsync service()
	{
		return service;
	}

    /** 
     * The entry point method, called automatically by loading a module
     * that declares an implementing class as an entry-point
     */
    public void onModuleLoad()
	{
		Panel rootPanel = RootPanel.get();
		rootPanel.add( mainPanel );
		final LoginWidget loginWidget = new LoginWidget();
		mainPanel.add( loginWidget );
		Panel poweredByJoliePanel = new HorizontalPanel();
		poweredByJoliePanel.setStylePrimaryName( "fsc-PoweredByJolie" );
		Image poweredByJolieImage = new Image( "fsc.UserWebUI/images/poweredByJolie.jpg" );
		poweredByJolieImage.addClickHandler( new ClickHandler() {
			public void onClick( ClickEvent event )
			{
				Window.open( "http://www.jolie-lang.org/", "_new", "" );
			}
		} );
		poweredByJoliePanel.add( poweredByJolieImage );
		mainPanel.add( poweredByJoliePanel );
		loginWidget.addLoginClickHandler( new ClickHandler() {
			public void onClick( ClickEvent event )
			{
				authenticationValue.getFirstChild( "username" ).setValue( loginWidget.username() );
				authenticationValue.getFirstChild( "password" ).setValue( loginWidget.password() );
				service.call( "authenticate", authenticationValue, new FSCCallback() {
					@Override
					public void onSuccess( Value response )
					{
						displayMainUI();
					}
				} );
			}
		} );
    }

	private void displayMainUI()
	{
		mainPanel.clear();
		mainPanel.add( new MainUI( this ) );
	}
}
