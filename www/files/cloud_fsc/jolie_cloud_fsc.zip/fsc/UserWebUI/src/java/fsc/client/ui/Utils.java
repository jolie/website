package fsc.client.ui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;

/**
 *
 * @author Fabrizio Montesi
 */
public class Utils
{
	public static void showMessageDialog( String message )
	{
		final DialogBox dialog = new DialogBox( false, true );
		dialog.setText( message );
		Button closeButton = new Button( "Close" );
		closeButton.addClickHandler( new ClickHandler() {
			public void onClick( ClickEvent event )
			{
				dialog.hide();
			}
		} );
		dialog.setWidget( closeButton );
		dialog.center();
		dialog.show();
	}
}
