package fsc.client.ui;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;

/**
 *
 * @author Fabrizio Montesi
 */
public class LoginWidget extends Composite
{
	private final TextBox usernameTextBox;
	private final PasswordTextBox passwordTextBox;
	private final Button loginButton;

	public LoginWidget()
	{
		Grid grid = new Grid( 4, 2 );
		grid.setStylePrimaryName( "fsc-Login" );
		grid.setText( 0, 0, "Login" );
		grid.getRowFormatter().setStylePrimaryName( 0, "fsc-Login-Header" );
		grid.setText( 1, 0, "Username" );
		grid.setText( 2, 0, "Password" );
		usernameTextBox = new TextBox();
		//usernameTextBox.setSize( "90", "16" );
		grid.setWidget( 1, 1, usernameTextBox );
		passwordTextBox = new PasswordTextBox();
		//passwordTextBox.setSize( "90", "16" );
		grid.setWidget( 2, 1, passwordTextBox );

		loginButton = new Button( "Login" );
		grid.setWidget( 3, 1, loginButton );
		initWidget( grid );
	}

	public void addLoginClickHandler( ClickHandler handler )
	{
		loginButton.addClickHandler( handler );
	}

	public String username()
	{
		return usernameTextBox.getText();
	}

	public String password()
	{
		return passwordTextBox.getText();
	}
}
