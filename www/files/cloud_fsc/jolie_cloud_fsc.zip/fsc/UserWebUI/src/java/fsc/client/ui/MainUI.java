package fsc.client.ui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;
import fsc.client.FSCCallback;
import fsc.client.UserWebUIEntryPoint;
import joliex.gwt.client.Value;
import joliex.gwt.client.ValueVector;

/**
 *
 * @author Fabrizio Montesi
 */
public class MainUI extends Composite
{
	private class StatusCodes {
		private static final int WORKING = 0;
		private static final int SUCCESS = 1;
		private static final int ERROR = 2;
	}

	private final UserWebUIEntryPoint entryPoint;
	private final ListBox applicationListBox = new ListBox();
	private Timer updateStatusTimer = null;
	private final Panel statusPanel;

	public MainUI( UserWebUIEntryPoint entryPoint )
	{
		this.entryPoint = entryPoint;
		this.statusPanel = new VerticalPanel();
		statusPanel.setStylePrimaryName( "fsc-JobStatusPanel" );
		init();
	}

	private void init()
	{
		Panel mainPanel = new HorizontalPanel();
		Panel vPanel = new VerticalPanel();
		vPanel.setStylePrimaryName( "fsc-MainLeftPanel" );
		mainPanel.add( vPanel );
		mainPanel.add( statusPanel );
		
		Panel applicationListPanel = new HorizontalPanel();
		applicationListPanel.setStylePrimaryName( "fsc-ApplicationListPanel" );
		applicationListPanel.add( new Label( "Select application: " ) );
		applicationListPanel.add( applicationListBox );
		Button refreshApplicationListButton = new Button( "Refresh application list" );
		refreshApplicationListButton.addClickHandler( new ClickHandler() {
			public void onClick( ClickEvent event )
			{
				fetchApplicationList();
			}
		} );
		applicationListPanel.add( refreshApplicationListButton );
		fetchApplicationList();
		vPanel.add( applicationListPanel );

		final TextArea inputArea = new TextArea();
		inputArea.setStylePrimaryName( "fsc-InputArea" );
		vPanel.add( inputArea );

		final Button runButton = new Button( "Run" );
		runButton.addClickHandler( new ClickHandler() {
			public void onClick( ClickEvent event )
			{
				clearJob();
				int selectedIndex = applicationListBox.getSelectedIndex();
				if ( selectedIndex < 0 ) {
					Utils.showMessageDialog( "You must select an application" );
				} else {
					Value request = new Value();
					request.getChildren( "authenticationData" ).set( 0, entryPoint.authenticationValue() );
					request.getFirstChild( "applicationName" ).setValue( applicationListBox.getValue( selectedIndex ) );
					request.getFirstChild( "inputData" ).setValue( inputArea.getText() );
					entryPoint.service().call( "runApplication", request, new FSCCallback() {
						@Override
						public void onSuccess( Value response )
						{
							startJobUpdating( response.intValue() );
						}
					});
				}
			}
		} );
		vPanel.add( runButton );

		fetchApplicationList();
		initWidget( mainPanel );
	}

	private void fetchApplicationList()
	{
		applicationListBox.clear();
		applicationListBox.addItem( "Downloading the application list..." );
		entryPoint.service().call( "getApplicationList", entryPoint.authenticationValue(), new FSCCallback() {
			@Override
			public void onSuccess( Value response )
			{
				applicationListBox.clear();
				for( Value appName : response.getChildren( "applicationName" ) ) {
					applicationListBox.addItem( appName.strValue() );
				}
			}
		} );
	}

	private void clearJob()
	{
		if ( updateStatusTimer != null ) {
			updateStatusTimer.cancel();
		}
		statusPanel.clear();
	}

	private void startJobUpdating( int jobId )
	{
		clearJob();
		Label jobTitle = new Label( "Job n°" + jobId + " status" );
		jobTitle.setStylePrimaryName( "fsc-JobStatusTitle" );
		statusPanel.add( jobTitle );
		final Panel jobPanel = new VerticalPanel();
		statusPanel.add( jobPanel );
		final Value request = new Value();
		request.getChildren( "authenticationData" ).set( 0, entryPoint.authenticationValue() );
		request.getFirstChild( "jobId" ).setValue( jobId );
		updateStatusTimer = new Timer() {
			@Override
			public void run()
			{
				entryPoint.service().call( "getJobStatus", request, new FSCCallback() {
					@Override
					public void onSuccess( Value response )
					{
						displayJobStatus( response, jobPanel );
						if ( response.intValue() == StatusCodes.WORKING ) {
							schedule( 1000 );
						}
					}
				} );
			}
		};
		updateStatusTimer.schedule( 1000 );
	}

	private void displayJobStatus( Value response, Panel jobPanel )
	{
		jobPanel.clear();
		final int columns = 4; // Node name - working - error - success
		ValueVector nodes = response.getChildren( "processingNode" );
		Grid grid = new Grid( nodes.size() + 1, columns );
		grid.setStylePrimaryName( "fsc-JobStatusGrid" );
		grid.setText( 0, 0, "Node" );
		grid.setWidget( 0, 1, new Image( "fsc.UserWebUI/images/operating.png" ) );
		grid.setWidget( 0, 2, new Image( "fsc.UserWebUI/images/error.png" ) );
		grid.setWidget( 0, 3, new Image( "fsc.UserWebUI/images/task-complete.png" ) );
		grid.getRowFormatter().setStylePrimaryName( 0, "fsc-JobStatusGrid-header" );
		int row = 1;
		Value nodeStatus;
		for( Value v : nodes ) {
			nodeStatus = v.getFirstChild( "status" );
			grid.setText( row, 0, v.getFirstChild( "name" ).strValue() );
			grid.setText( row, 1, nodeStatus.getFirstChild( "working" ).strValue() );
			grid.setText( row, 2, nodeStatus.getFirstChild( "error" ).strValue() );
			grid.setText( row, 3, nodeStatus.getFirstChild( "success" ).strValue() );
			if ( row % 2 == 0 ) {
				grid.getRowFormatter().setStylePrimaryName( row, "fsc-JobStatusGrid-row-even" );
			} else {
				grid.getRowFormatter().setStylePrimaryName( row, "fsc-JobStatusGrid-row-odd" );
			}
			row++;
		}

		jobPanel.add( grid );
		Label resultLabel;
		switch( response.intValue() ) {
			case StatusCodes.WORKING:
				break;
			case StatusCodes.SUCCESS:
				resultLabel = new Label( "Result: " + response.getFirstChild( "result" ).strValue() );
				resultLabel.setStylePrimaryName( "fsc-Result" );
				jobPanel.add( resultLabel );
				break;
			case StatusCodes.ERROR:
				resultLabel = new Label( "Job terminated with an error" );
				resultLabel.setStylePrimaryName( "fsc-Result" );
				jobPanel.add( resultLabel );
				break;
		}
	}
}
