package fsc.client;

import fsc.client.ui.Utils;
import joliex.gwt.client.FaultException;
import joliex.gwt.client.JolieCallback;

/**
 *
 * @author Fabrizio Montesi
 */
public abstract class FSCCallback extends JolieCallback
{
	@Override
	protected void onFault( FaultException fault )
	{
		Utils.showMessageDialog( fault.faultName() + (fault.getMessage().isEmpty() ? "" : ": " + fault.getMessage()) ) ;
	}

	@Override
	protected void onError( Throwable t )
	{
		Utils.showMessageDialog( t.toString() );
	}
}
