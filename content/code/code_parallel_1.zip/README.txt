run the following services into different consoles:
getinfo.ol
traffic.ol
forecast.ol

then run the client.ol with a city name as a parameter.
try with Rome, Cesena or what you want